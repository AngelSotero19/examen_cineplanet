import { Module } from '@nestjs/common';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import { CreditCardService } from './credit-card/credit-card.service';
import { CreditCardService } from './credit-card/dto/credit-card/credit-card.service';
import { CreditCardService } from './modules/credit-card/dto/credit-card/credit-card.service';

@Module({
  imports: [],
  controllers: [AppController],
  providers: [AppService, CreditCardService],
})
export class AppModule {}
