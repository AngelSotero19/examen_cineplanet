// card.controller.ts
import { Controller, Post, Body, Headers } from '@nestjs/common';
import { CardService } from './credit-card.service';
import { CardDTO } from './credit-card.dto';

@Controller('card')
export class CardController {
  constructor(private readonly cardService: CardService) {}

  @Post('authorize')
  async authorizeCard(@Body() cardDTO: CardDTO, @Headers('X-Comercio-ID') comercioId: string) {
    return this.cardService.authorizeCard(cardDTO, comercioId);
  }
}
